package com.ebupt.wifibox;

import org.litepal.LitePalApplication;

/**
 * Created by zhaoqin on 4/21/15.
 */
public class MyApp extends LitePalApplication{
    public String phone;

}
